package ip_rechner_eschenhorn.Calculators;

import java.util.ArrayList;

/**
 * Contractually determined Strategy Method
 * @author Jennifer
 */
public interface Strategy {
	
	/**
     * Converts for correct Strategy
     * @param String type
     * @param String input
     * @return ArrayList<String>
     */
	public ArrayList<String> convert(String input, String type);
}
