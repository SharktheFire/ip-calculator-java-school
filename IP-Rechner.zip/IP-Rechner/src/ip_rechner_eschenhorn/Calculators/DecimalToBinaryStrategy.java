package ip_rechner_eschenhorn.Calculators;

import java.util.ArrayList;

import ip_rechner_eschenhorn.Splitter;

/**
 * Convert correct with DecimalToBinaryStrategy
 * @author Jennifer
 */
public class DecimalToBinaryStrategy implements Strategy {

    /**
     * Stores splitter for accessing in convert method.
     */
	private Splitter splitter;
	
	/**
     * Constructor of DecimalToBinaryStrategy
     * @param Splitter
     */
	public DecimalToBinaryStrategy(Splitter splitter) {
		this.splitter = splitter;
	}
	
	/**
     * Converts Decimal to Binary
     * @param String type
     * @param String input
     * @return ArrayList<String>
     */
	public ArrayList<String> convert(String input, String type) {		
		ArrayList<String> binarys = new ArrayList<String>();
		for (Integer digit: this.splitter.seperating(input, type)) {
			binarys.add(Integer.toString(digit, 2));
		}
		return binarys;
	}
}
