package ip_rechner_eschenhorn.Calculators;

import java.util.ArrayList;

import ip_rechner_eschenhorn.Splitter;

/**
 * Convert correct with DecimalToHexadecimalStrategy
 * @author Jennifer
 */
public class DecimalToHexadecimalStrategy implements Strategy {

	/**
     * Stores splitter for accessing in convert method.
     */
	private Splitter splitter;
	
	/**
     * Constructor of DecimalToHexadecimalStrategy
     * @param Splitter
     */
	public DecimalToHexadecimalStrategy(Splitter splitter) {
		this.splitter = splitter;
	}
	
	/**
     * Converts Decimal to Hexadecimal
     * @param String type
     * @param String input
     * @return ArrayList<String>
     */
	public ArrayList<String> convert(String input, String type) {	
		ArrayList<String> hexadecimals = new ArrayList<String>();
		for (Integer digit: this.splitter.seperating(input, type)) {
			hexadecimals.add(Integer.toString(digit, 16).toUpperCase());
		}
		return hexadecimals;
	}

}
