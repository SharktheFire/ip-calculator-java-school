package ip_rechner_eschenhorn.Calculators;

import java.util.ArrayList;

import ip_rechner_eschenhorn.Splitter;

/**
 * Convert correct with DecimalToOctalStrategy
 * @author Jennifer
 */
public class DecimalToOctalStrategy implements Strategy {
	
	/**
     * Stores splitter for accessing in convert method.
     */
	private Splitter splitter;
	
    /**
     * Constructor of DecimalToOctalStrategy
     * @param Splitter
     */
	public DecimalToOctalStrategy(Splitter splitter) {
		this.splitter = splitter;
	}
	
	/**
     * Converts Decimal to Octal
     * @param String type
     * @param String input
     * @return ArrayList<String>
     */
	public ArrayList<String> convert(String input, String type) {
		ArrayList<String> octals = new ArrayList<String>();
		for (Integer digit: this.splitter.seperating(input, type)) {
			octals.add(Integer.toString(digit, 8));
		}
		return octals;
	}
}
