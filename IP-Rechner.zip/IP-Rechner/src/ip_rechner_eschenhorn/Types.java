package ip_rechner_eschenhorn;

/**
 * Store specific Types for having them on one place
 * @author Jennifer
 */
public class Types {
	final static String CALCULATOR_HEXADECIMAL = "hexadecimal";
	final static String CALCULATOR_BINARY = "binary";
	final static String CALCULATOR_OCTAL = "octal";
	
	final static String TYPE_IPV4_ADDRESS = "IPv4";
	final static String TYPE_CALCULATOR = "Calculator";
}
