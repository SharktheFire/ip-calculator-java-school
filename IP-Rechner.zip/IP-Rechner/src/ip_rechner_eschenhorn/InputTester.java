package ip_rechner_eschenhorn;

import ip_rechner_eschenhorn.IP.IPv4;

/**
 * Incoming input checking of user ...
 * @author Jennifer
 */
public class InputTester {
	
	/**
     * Checking coming input of user with some conditions
     * @param String type
     * @param String input
     * @return boolean
     */
	public boolean check(String input, String type) {
				
		if (type == Types.TYPE_IPV4_ADDRESS) {
			IPv4 ip = new IPv4();
			return ip.check(input, type);
		}
		
		if (type == Types.TYPE_CALCULATOR) {
			if (input.startsWith(Types.CALCULATOR_BINARY)) {				
				return true;
			}
			if (input.startsWith(Types.CALCULATOR_HEXADECIMAL)) {				
				return true;
			}
			if (input.startsWith(Types.CALCULATOR_OCTAL)) {				
				return true;
			}
		}
		return false;
	}
}
