package ip_rechner_eschenhorn;

import java.util.ArrayList;

/**
 * Formatter
 * @author Jennifer
 */
public class OutputFormatter {	
	/**
     * Format correct output for user
     * @param ArrayList<String>
     * @return void
     */
	public void output(ArrayList<String> convertedDigits) {	
		System.out.println("=> " + String.join(".", convertedDigits));
	}
}
