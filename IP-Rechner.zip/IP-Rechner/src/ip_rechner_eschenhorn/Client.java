package ip_rechner_eschenhorn;

import java.util.Scanner;

import ip_rechner_eschenhorn.Calculators.Strategy;

/**
 * Client which is communicating with user - Main method
 * @author Jennifer
 */
public class Client {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		// TesterInput for IPv4 address
		System.out.println("Welcome to the IP-Calculator!");
		System.out.println("Please insert one IPv4 Adress:");
		String input = reader.nextLine();
				
		InputTester tester = new InputTester();
		while (tester.check(input, Types.TYPE_IPV4_ADDRESS) == false) {
			System.out.println("Wrong input! Please try again.");
			System.out.println("Please insert new IPv4 Address:");
			input = reader.nextLine();
		}

		String calculatorTypes = Types.CALCULATOR_BINARY + ", " + Types.CALCULATOR_HEXADECIMAL + ", " + Types.CALCULATOR_OCTAL;
		
		// TesterInput for Calculator
		System.out.println("Convert into: " + calculatorTypes + "?");
		String calculator = reader.nextLine();
		
		while (tester.check(calculator, Types.TYPE_CALCULATOR) == false) {
			System.out.println("Wrong input! Please try again.");
			System.out.println("Convert into: " +  calculatorTypes + "?");
			calculator = reader.nextLine();
		}
		reader.close();
		
		// Converting with correct strategy and output to user
		Strategy strategy = StrategyFactory.decideWhichCalculator(calculator);
		OutputFormatter formatter = new OutputFormatter();
		
		formatter.output(strategy.convert(input, Types.TYPE_IPV4_ADDRESS));
	}
}
