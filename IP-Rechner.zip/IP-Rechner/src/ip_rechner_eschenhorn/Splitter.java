package ip_rechner_eschenhorn;

import java.util.ArrayList;

/**
 * Splitter for inserted IP Address
 * @author Jennifer
 */
public class Splitter {
	/**
     * Seperating incoming input from user for making calculating better
     * @param String type
     * @param String input
     * @return ArrayList<Integer>
     */
	public ArrayList<Integer> seperating(String input, String type) {	
		ArrayList<Integer> array = new ArrayList<Integer>();
		if (type == Types.TYPE_IPV4_ADDRESS) {
			for (String a : input.split("\\.")) {
				try {
					array.add(Integer.parseInt(a));					
				} catch (Exception e) {
					System.out.println("Something went wrong!");
				}
			}	 	
		}
		
		return array;
	}
}
