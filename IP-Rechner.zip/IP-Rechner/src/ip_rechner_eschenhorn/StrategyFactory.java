package ip_rechner_eschenhorn;

import ip_rechner_eschenhorn.Calculators.DecimalToHexadecimalStrategy;
import ip_rechner_eschenhorn.Calculators.DecimalToOctalStrategy;
import ip_rechner_eschenhorn.Calculators.DecimalToBinaryStrategy;
import ip_rechner_eschenhorn.Calculators.Strategy;

/**
 * Factory for using correct Strategy
 * @author Jennifer
 */
public class StrategyFactory {
	/**
     * Static decision maker for correct calculator 
     * @param String calculator
     * @return Stratgey
     */
	public static Strategy decideWhichCalculator(String calculator) {
		
		Splitter splitter = new Splitter();
		
		switch (calculator) {
			case Types.CALCULATOR_BINARY:
				return new DecimalToBinaryStrategy(splitter);
			case Types.CALCULATOR_HEXADECIMAL:
				return new DecimalToHexadecimalStrategy(splitter);
			case Types.CALCULATOR_OCTAL:
				return new DecimalToOctalStrategy(splitter);	
		}
		return null;
	}
}
