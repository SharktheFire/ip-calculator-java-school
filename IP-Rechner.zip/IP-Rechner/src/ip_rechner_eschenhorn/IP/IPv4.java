package ip_rechner_eschenhorn.IP;

import java.util.ArrayList;

import ip_rechner_eschenhorn.Splitter;

/**
 * Child class of IP with checking conditions
 * @author Jennifer
 */
public class IPv4 extends IP {
	/**
     * Stores Integer of lowestPossibleNumberONFirstChar
     * {@value}
     */
	private Integer lowestPossibleNumberOnFirstChar = 1;
	
	/**
     * Constructor of IPv4
     */
	public IPv4() {
		super();
		this.numberOfDots = 3;
		this.highestPossibleNumber = 255;
		this.lowestPossibleNumber = 0;
	}
	
	/**
     * Checking Conditions for IPv4 Address
     * @param String type
     * @param String input
     * @return boolean
     */
	public boolean check(String input, String type) {
		if (input.length() - input.replace(".", "").length() == this.numberOfDots) {
			
			Splitter splitter = new Splitter();
			ArrayList<Integer> digits = splitter.seperating(input, type);
			
			if (digits.get(0) >= this.lowestPossibleNumberOnFirstChar && digits.get(0) <= this.highestPossibleNumber) {
				digits.remove(0);
				for (Integer digit : digits) {
					if (digit >= this.lowestPossibleNumber && digit <= this.highestPossibleNumber) {
						return true;
					}
				}
			}
		}
		return false;
	}
}
