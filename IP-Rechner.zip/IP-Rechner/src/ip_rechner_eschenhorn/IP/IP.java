package ip_rechner_eschenhorn.IP;

/**
 * Super class with specified proberties of IP
 * @author Jennifer
 */
public abstract class IP {
	/**
     * Stores Integer of numberOfDots.
     */
	protected Integer numberOfDots;
	
	/**
     * Stores Integer of highestPossibleNumber.
     */
	protected Integer highestPossibleNumber;
	
	/**
     * Stores Integer of lowestPossibleNumber.
     */
	protected Integer lowestPossibleNumber;
}